
bank32.crt: Bank32's public-key certificate, signed by ModelCA.
            
bank32.key: Bank32's private key
            The password used for protecting the private key is "dees". 

modelCA.crt: ModelCA's public-key certificate

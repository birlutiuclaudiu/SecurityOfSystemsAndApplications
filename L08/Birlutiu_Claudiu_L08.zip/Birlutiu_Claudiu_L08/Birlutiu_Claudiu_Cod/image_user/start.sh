#!/bin/bash
  
# Copy the prepared resolv.conf file
cp /etc/resolv.conf.override /etc/resolv.conf

# Start the shell
/bin/bash

